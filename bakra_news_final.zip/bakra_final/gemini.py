"""Gemini API (free tier). Model ka naam khud Google se poochhta hai."""
import json
import os
import re
import time
import urllib.error
import urllib.request

BASE = "https://generativelanguage.googleapis.com/v1beta"
_models = []


def _get(url, key, body=None):
    req = urllib.request.Request(url, json.dumps(body).encode() if body else None,
                                 {"Content-Type": "application/json", "x-goog-api-key": key})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.load(r)


def models(key):
    """Is key par jo text models chalte hain, unki list (flash pehle)."""
    if _models:
        return _models
    names = []
    try:
        data = _get(f"{BASE}/models?pageSize=200", key)
        for m in data.get("models", []):
            n = m["name"].split("/")[-1]
            if "generateContent" not in m.get("supportedGenerationMethods", []):
                continue
            if re.search(r"tts|image|embed|audio|live|vision|aqa|learnlm|gemma", n):
                continue
            names.append(n)
    except Exception as e:                            # noqa: BLE001
        print("  model list nahi mili:", e)
    def rank(n):
        return (0 if "flash" in n and "lite" not in n else 1 if "flash" in n else 2,
                0 if "latest" in n else 1, -len(re.findall(r"\d", n)), n)
    names.sort(key=rank)
    env = os.getenv("GEMINI_MODEL")
    _models[:] = ([env] if env else []) + names[:5] + ["gemini-flash-latest"]
    print("  Gemini models:", ", ".join(_models))
    return _models


def ask(prompt, search=False, json_mode=False, temperature=0.9):
    key = os.environ["GEMINI_API_KEY"]
    body = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": temperature}}
    if search:
        body["tools"] = [{"google_search": {}}]
    elif json_mode:
        body["generationConfig"]["responseMimeType"] = "application/json"
    errors = []
    for model in models(key):
        for attempt in range(2):
            try:
                data = _get(f"{BASE}/models/{model}:generateContent", key, body)
                return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"])
            except urllib.error.HTTPError as e:
                msg = e.read().decode("utf-8", "ignore")[:300]
                errors.append(f"{model}: {e.code} {msg}")
                if e.code == 429 and "limit: 0" not in msg and attempt == 0:
                    time.sleep(30)                    # thodi der ruk kar dobara
                    continue
                break                                 # agla model
            except Exception as e:                    # noqa: BLE001
                errors.append(f"{model}: {e!r}")
                break
    raise RuntimeError("Gemini nahi chala:\n  " + "\n  ".join(errors))


def json_from(text):
    m = re.search(r"```(?:json)?\s*(.+?)```", text, re.S)
    s = m.group(1) if m else text
    start = min([i for i in (s.find("{"), s.find("[")) if i >= 0] or [0])
    return json.loads(s[start:s.rfind("}" if s[start] == "{" else "]") + 1])
